// Copyright Epic Games, Inc. All Rights Reserved.

#include "Project_FatedBrand.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Project_FatedBrand, "Project_FatedBrand" );
